-- NGIS: Weekly topics for Secondary (run once in Supabase -> SQL Editor; safe to run again)
create table if not exists public.weekly_topics (
  id uuid primary key default gen_random_uuid(),
  class_id text not null,
  week_id text not null,
  subject_id text not null,
  topic text not null,
  teacher_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (class_id, week_id, subject_id)
);
alter table public.weekly_topics enable row level security;
drop policy if exists "wt_select" on public.weekly_topics;
drop policy if exists "wt_insert" on public.weekly_topics;
drop policy if exists "wt_update" on public.weekly_topics;
drop policy if exists "wt_delete" on public.weekly_topics;
create policy "wt_select" on public.weekly_topics for select to anon, authenticated using (true);
create policy "wt_insert" on public.weekly_topics for insert to anon, authenticated with check (true);
create policy "wt_update" on public.weekly_topics for update to anon, authenticated using (true) with check (true);
create policy "wt_delete" on public.weekly_topics for delete to anon, authenticated using (true);
